package ex01;

public interface Calc {
	int plus(int a, int b);
	int minus(int a, int b);
}
