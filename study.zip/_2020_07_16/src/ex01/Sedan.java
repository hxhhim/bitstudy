package ex01;

public interface Sedan extends Motor {
	void run();
	void openSunroof();
	

}
