package ex01;

public abstract class Sedan1 implements Sedan{
	
}
