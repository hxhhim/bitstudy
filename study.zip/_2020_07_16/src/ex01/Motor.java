package ex01;

public interface Motor {
	void start();
	
}
