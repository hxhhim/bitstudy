package ex01;

public interface Fly {
	void run();
	void takeOff();
}
