package ex01;

class A{}
interface I{}

class C extends A{}
class B implements I{}
//class D extends I{}
//class D implements A{}

//interface If extends A{}
//interface IF implements I{}
interface IF extends I{}
//interface IF1 implements A{}


public class Sedan3 implements Sedan{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void openSunroof() {
		// TODO Auto-generated method stub
		
	}

}
