package ex01;

public class MyCarAdapter implements BitCar {

	@Override
	public void run() {}

	@Override
	public void openSunroof() {}

	@Override
	public void start() {}

	@Override
	public void dump() {}

	@Override
	public void stop() {}

}
