package ex01;

public interface Car {
	void run();
	void stop();
}
