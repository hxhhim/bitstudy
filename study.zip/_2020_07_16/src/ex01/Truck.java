package ex01;

public interface Truck extends Motor {
	
	 void run();
	 void dump();

}
