package ex01;

public class Test05 {

	public static void main(String[] args) {
		Texi texi = new Texi();
		
		texi.start();
		texi.run();
		texi.stop();
		
	}

}
