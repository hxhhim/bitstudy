package ex05;

public class Test03 {

	public static void main(String[] args) {
//		Test02 t = new Test02();
//		Test02.A p = t.new A();
//		p.print();
		
		Test02.A p = new Test02.A();
		p.print();
	}

}
