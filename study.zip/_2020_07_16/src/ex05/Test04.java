package ex05;

import ex05.Test02.A;

public class Test04 {

	public static void main(String[] args) {
		A p = new A();

	}

}
