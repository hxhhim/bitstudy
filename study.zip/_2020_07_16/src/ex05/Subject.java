package ex05;

public class Subject {
	static class programming{
		static final int JAVA = 11;
		static final int C = 12;
		static final int cpp= 13;
	}
	static class language{
		static final int ENGLISH =21;
		static final int KOREAN = 22;
	}
	static class art{
		static final int PHOTO = 13;
	}
}
