package step01;

public class A {
	int var1 = 100;
}
