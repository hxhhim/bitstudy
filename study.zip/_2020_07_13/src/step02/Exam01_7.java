package step02;

public class Exam01_7 {

	public static void main(String[] args) {
		String s2 = new String("abcdefghijk").substring(3);
		System.out.println(s2);
		
		String s4 = "abcdefghijk".substring(3);
		System.out.println(s4);
		
	}

}
