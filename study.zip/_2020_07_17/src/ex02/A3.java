package ex02;

public class A3 {
	int a;
	final int x = 0;
	void print() {
		System.out.println(a);
	}
	public static void main(String[] args) {
		A3 a = new A3();
		a.print();
	}

}
