package ex03;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Exam11 {

	public static void main(String[] args) throws IOException {
		FileOutputStream out = new FileOutputStream("Exam11.dat");
		
		byte[] bytes= {10,20,30,40,50,60,70,80,90,100};
		
		for(int i = 0; i<bytes.length;i++) {
			out.write(bytes[i]);
		}
		out.close();
		System.out.println("�����Ͽ����ϴ�.");
		
		File f = new File("Exam11.dat");
		FileInputStream in = new FileInputStream(f);
		
		int b;
		b= in.read();
		System.out.println(Integer.toHexString(b));
		for(int i=0; i<9; i++) {
		System.out.println(Integer.toHexString(in.read()));
		}
		in.close();
		System.out.println("�о����ϴ�.");
	}

}
