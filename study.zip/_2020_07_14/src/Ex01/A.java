package Ex01;

public class A {
	int a =10;
	protected A() {
		System.out.println("A() ");
	}
}
