package Ex01;

public class B extends A {
	public B() {
		System.out.println("B() ");
		
	}
}
