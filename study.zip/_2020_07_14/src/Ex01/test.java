package Ex01;

public class test {

	public static void main(String[] args) {
		A test = new A();

	}

}
