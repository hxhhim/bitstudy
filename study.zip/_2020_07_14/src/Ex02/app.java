package Ex02;
import Ex01.*;
public class app extends A{
	
	public app() {
		super();
	}
	public static void main(String[] args) {
		app test = new app();
		B test1 = new B();
	}
}
