package Ex03;

public class C extends A{
	int c = 10;
	
	public void Draw() {
		System.out.println("�׸�׷���");
	}
}
