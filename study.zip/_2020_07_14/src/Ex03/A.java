package Ex03;

public class A {
	int a = 10;
	
	public void Draw() {
		System.out.println("A.print()");
	}
}
