package Ex06;

public class infMain implements inf{

	public static void main(String[] args) {
		

	}

	@Override
	public void get() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void set() {
		// TODO Auto-generated method stub
		
	}

}
