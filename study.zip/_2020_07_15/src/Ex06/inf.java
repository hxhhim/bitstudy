package Ex06;

public interface inf {
	public void get();
	public void set();
}
