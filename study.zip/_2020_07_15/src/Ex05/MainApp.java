package Ex05;

public class MainApp {

	public static void main(String[] args) {
		
		ChatFrame f = new ChatFrame();
		f.setVisible(true);

	}

}
