package Ex04;

import java.awt.Frame;

public class Exam02 extends Frame{

	public Exam02() {
		super("������ ����");
		setSize(400,300);
	}
	public static void main(String[] args) {
		Exam02 f = new Exam02();
		f.setVisible(true);
		

	}

}
