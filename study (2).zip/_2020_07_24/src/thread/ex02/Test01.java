package thread.ex02;

public class Test01 {

	public static void main(String[] args) {
		

	}

}
