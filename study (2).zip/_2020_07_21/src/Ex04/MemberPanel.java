package Ex04;

import java.awt.Label;
import java.awt.Panel;

public class MemberPanel extends Panel{
	public MemberPanel() {
		Label label = new Label("ȸ�� ȭ��");
		add(label);
	}
}
