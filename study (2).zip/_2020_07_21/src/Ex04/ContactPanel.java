package Ex04;

import java.awt.Label;
import java.awt.Panel;

public class ContactPanel extends Panel{
	public ContactPanel() {
		Label label = new Label("����ó ȭ��");
		add(label);
	}
}
