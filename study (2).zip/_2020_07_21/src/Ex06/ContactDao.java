package Ex06;

public class ContactDao {

}
