package Ex05;

import java.awt.Label;
import java.awt.Panel;

public class ProjectPanel extends Panel{
	public ProjectPanel() {
		Label label = new Label("Project ȭ��");
		add(label);
	}
}
