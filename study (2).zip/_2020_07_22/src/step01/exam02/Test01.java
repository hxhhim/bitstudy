package step01.exam02;

public class Test01 {

	public static void main(String[] args) {
		Score s = new Score();
		s.name = "ȫ�浿";
		s.kor = 100;
		s.math = 90;
		s.eng = 100;
		
//		s.sum = s.kor + s.math + s.eng;
//		s.aver = s.sum/3f;
//		
//		System.out.printf("�հ�: %d, ��� %.2f\n", s.sum,s.aver);//�������Ŭ����

	}

}
