package step01.exam01;

public class Score {
	String name;
	int kor;
	int math;
	int eng;
	int sum;
	float aver;
	
}
