package step01.exam01;

public class Patient {
	String name;
	int age;
	float weight;
	float height;
	boolean gender;
	
}
