package step01.exam04;

import step01.exam03.C;

class F{
	public void dm() {
	C c = new C();
	c.setv1_1(30);
	c.v4=6;
}
}
public class E extends C {
	public void dm() {
		C c = new C();
		c.setv1_1(100);
		
		setv1_1(100);
		 v2 = 200;
		 v3 = 300;
		 v4 = 400;
	 }
}
