package List;

public class Node {
	int value;	//����,boolean,���ڿ�
	Node next;
	
	public Node() {
		
	}
	public Node(int value) {
		this.value =value;
	}
}
